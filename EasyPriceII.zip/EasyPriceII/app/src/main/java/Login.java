public class Login {
    private static final String USUARIO = "THECLUB";
    private static final String SENHA = "123456";
}
