package carlos.robson.easyprice.Persistencia;

/**
 * Classse que cria a conexão com o banco de dados.
 */
public class InicializaBD {
    /**
     * TODO
     */
}
