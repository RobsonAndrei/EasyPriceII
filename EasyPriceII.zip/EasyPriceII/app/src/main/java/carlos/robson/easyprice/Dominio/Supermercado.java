package carlos.robson.easyprice.Dominio;

public class Supermercado {

    private String idSupermercado;
    private String nome;

    public String getIdSupermercado() {

        return idSupermercado;
    }

    public String getNome() {
        return nome;
    }

    public void setIdSupermercado(String idSupermercado) {
        this.idSupermercado = idSupermercado;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }

}
