package carlos.robson.easyprice;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;

    private ViewHolder mViewHolder = new ViewHolder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mViewHolder.botaoCadUsuario = findViewById(R.id.ButtCadastUsu);

        this.mViewHolder.botaoCadUsuario.setOnClickListener(this);


        this.mViewHolder.botaoCadProduto = findViewById(R.id.ButtCadastProd);

        this.mViewHolder.botaoCadProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //setContentView(R.layout.activity_telacadusuario);
                Intent it = new Intent(MainActivity.this, TelaCadProduto.class);
                startActivity(it);
            }
        });

        this.mViewHolder.botaoBuscaProd = findViewById(R.id.ButtBuscaProd);
        this.mViewHolder.botaoQualProd = findViewById(R.id.ButtQualifPro);
        this.mViewHolder.botaoExibHisComp = findViewById(R.id.ButtExibiHist);
        this.mViewHolder.botaoBuscMelhoOf = findViewById(R.id.ButtBuscMelhorOfer);
        this.mViewHolder.botaoComparaPre = findViewById(R.id.ButtComparaPre);
        this.mViewHolder.botaoConfig = findViewById(R.id.Buttconfiguracoes);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.ButtCadastUsu) {

            Intent it = new Intent(MainActivity.this, TelacadusuarioActivity.class);
            startActivity(it);

        }
    }

    // ==================== Implementação do ViewHolder ================================
    private static class ViewHolder {
        Button botaoCadUsuario;
        Button botaoCadProduto;
        Button botaoBuscaProd;
        Button botaoQualProd;
        Button botaoExibHisComp;
        Button botaoBuscMelhoOf;
        Button botaoComparaPre;
        Button botaoConfig;

    }

}
