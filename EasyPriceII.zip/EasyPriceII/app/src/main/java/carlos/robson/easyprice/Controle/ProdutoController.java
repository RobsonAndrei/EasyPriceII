package carlos.robson.easyprice.Controle;

public class ProdutoController {
}
