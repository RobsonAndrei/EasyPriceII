package carlos.robson.easyprice.Dominio;

public class Produto {
}
