package carlos.robson.easyprice.Dominio;

public class HistoricoAvaliacao {
}
