package carlos.robson.easyprice.Controle;

public class BuscaController {
}
